var code = '1234';
var entry = '';

function getE(id) { return document.getElementById(id); }

function loginKey(key) {
 var out = getE('login-code');

 entry += key;
 out.value += ' * ';
}

function loginClear() {
 var out = getE('login-code');

 entry = '';
 out.value = '';
}

function loginConfirm() {
 if(entry == "4444"){
     alert("Descubriste el código!")
 }else{
 alert("intenta de nuevo "+entry)
}
}
