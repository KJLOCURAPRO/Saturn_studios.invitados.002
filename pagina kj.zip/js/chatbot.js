let historial = [];

const chatLog = document.getElementById('chat-log');
const userInputStream = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');

sendBtn.addEventListener('click', () => {
if (userInputStream.value !== '') {
const userText = userInputStream.value;
historial.push(userText);
const normalizedText = normalizarTexto(userText);
chatLog.innerHTML += `<p>Tú: ${userText}</p>`;
const response = getResponse(normalizedText, historial);
chatLog.innerHTML += `<p>Chatbot: ${response}</p>`;
userInputStream.value = '';
}
});

function getResponse(userText, historial) {
if (historial.length > 1) {
const ultimoMensaje = historial[historial.length - 1];
if (ultimoMensaje === 'Hola') {
return '¡Hola de nuevo! ¿Qué tal?';
}
}
switch (userText) {
case 'hola':
return '¡Hola! ¿Cómo estás?';
case 'adiós':
return '¡Adiós! Que tengas un buen día.';
case 'bien':
return '¡Me alegro por ti!'
case 'mal':
return '¿Que te ha pasado?'
case 'Quien te creo':
return 'AIR GAMES es una empresa de 20 trabajadores los cuales trabajan en programas juegos páginas y modificar juegos como: Minecraft, Terraria, Lostminer etc. He marcado los más comunes ya que son los que la gente trabaja o pide colaboración con ellos como KJLOCURAPRO el creador de esta página y de mi el cual pidió la ayuda a AIR GAMES para modificar Minecraft y le ayudará con los estilos de sus paginas web actualmente yo solo fui creado independientente por KJLOCURAPRO sin ayuda de nadie ya que el proyecto comenzó como una broma entre amigos de el.'
case 'quien es Air games':
return 'AIR GAMES es una empresa de 20 trabajadores los cuales trabajan en programas juegos páginas y modificar juegos como: Minecraft, Terraria, Lostminer etc. He marcado los más comunes ya que son los que la gente trabaja o pide colaboración con ellos como KJLOCURAPRO el creador de esta página y de mi el cual pidió la ayuda a AIR GAMES para modificar Minecraft y le ayudará con los estilos de sus paginas web actualmente yo solo fui creado independientente por KJLOCURAPRO sin ayuda de nadie ya que el proyecto comenzó como una broma entre amigos de el.'
case 'que es air games':
return 'AIR GAMES es una empresa de 20 trabajadores los cuales trabajan en programas juegos páginas y modificar juegos como: Minecraft, Terraria, Lostminer etc. He marcado los más comunes ya que son los que la gente trabaja o pide colaboración con ellos como KJLOCURAPRO el creador de esta página y de mi el cual pidió la ayuda a AIR GAMES para modificar Minecraft y le ayudará con los estilos de sus paginas web actualmente yo solo fui creado independientente por KJLOCURAPRO sin ayuda de nadie ya que el proyecto comenzó como una broma entre amigos de el.'

default:
return 'Lo siento, no entiendo.';
}
}

function normalizarTexto(texto) {
return texto.toLowerCase().replace(/[^a-zñ0-9]/g, "");
}